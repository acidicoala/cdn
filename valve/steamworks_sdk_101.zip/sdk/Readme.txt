This is the Steamworks SDK v1.0

================================================================

Copyright � 1996-2008, Valve Corporation, All rights reserved.

================================================================


Welcome to the Steamworks SDK.  For documentation please see our partner 
website at: http://partner.steamgames.com.


Revision History:

v1.0:

- Initial Steamworks SDK release